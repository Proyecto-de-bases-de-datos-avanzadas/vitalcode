package DAO;

/**
 *
 * @author ErnestoLpz_252663
 */
public interface IDireccionDAO {
    
}
